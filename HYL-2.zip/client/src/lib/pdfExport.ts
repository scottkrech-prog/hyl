import { CommitmentLetter } from "../../../drizzle/schema";

export async function generateTransformationPDF(commitment: CommitmentLetter) {
  // Create a simple HTML document for PDF generation
  const formatDate = (date: Date | null | undefined) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  };

  const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>My 6-Month Transformation Commitment</title>
  <style>
    body {
      font-family: Georgia, serif;
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      line-height: 1.6;
      color: #333;
    }
    h1 {
      text-align: center;
      color: #1e40af;
      border-bottom: 3px solid #fbbf24;
      padding-bottom: 10px;
    }
    .date {
      text-align: center;
      font-style: italic;
      color: #666;
      margin-bottom: 30px;
    }
    .letter {
      background: #fffbeb;
      border: 2px solid #fbbf24;
      padding: 30px;
      border-radius: 8px;
    }
    .opening {
      font-size: 1.2em;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .commitment-text {
      font-size: 1.1em;
      font-weight: 600;
      margin: 20px 0;
    }
    .section {
      margin: 20px 0;
    }
    .section-title {
      font-weight: bold;
      color: #1e40af;
      margin-bottom: 8px;
    }
    .section-content {
      font-style: italic;
      margin-left: 20px;
    }
    ul {
      margin-left: 40px;
    }
    .signature {
      margin-top: 40px;
      text-align: center;
    }
    .signature-line {
      border-top: 2px solid #333;
      width: 300px;
      margin: 20px auto 10px;
      padding-top: 10px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <h1>My 6-Month Transformation Commitment</h1>
  <div class="date">Commitment Date: ${formatDate(commitment.commitmentDate)}</div>
  
  <div class="letter">
    <p class="opening">Dear Future Me,</p>
    
    <p class="commitment-text">
      Today, I am making a short 6-month commitment to myself, that will change the trajectory of my life FOREVER.
    </p>

    <div class="section">
      <div class="section-title">I am committing to this transformation because:</div>
      <div class="section-content">${commitment.whyText}</div>
    </div>

    <div class="section">
      <div class="section-title">Six months from now, on ${formatDate(commitment.targetDate)}, I will have:</div>
      <ul>
        <li>${commitment.goal1}</li>
        <li>${commitment.goal2}</li>
        <li>${commitment.goal3}</li>
      </ul>
    </div>

    <div class="section">
      <div class="section-title">The person I am becoming is someone who:</div>
      <div class="section-content">${commitment.becomingText}</div>
    </div>

    <div class="section">
      <div class="section-title">I know this journey won't be easy. When I face setbacks, I will remember:</div>
      <div class="section-content">${commitment.setbackReminder}</div>
    </div>

    <div class="section">
      <div class="section-title">I am doing this for:</div>
      <div class="section-content">${commitment.doingThisFor}</div>
    </div>

    <div class="section">
      <div class="section-title">I commit to:</div>
      <ul>
        <li>Completing all 11 phases of this planning system</li>
        <li>Starting Day 1 immediately after completion</li>
        <li>Following my daily rituals consistently</li>
        <li>Getting up one more time than I fall down</li>
        <li>Becoming the person I'm meant to be</li>
      </ul>
    </div>

    <div class="section">
      <div class="section-title">I understand that:</div>
      <ul>
        <li>Imperfect action beats perfect planning</li>
        <li>What's easy to do is also easy not to do - I choose to do</li>
        <li>For things to change, I must change</li>
        <li>Six months from now, I will look back at this moment as the turning point</li>
      </ul>
    </div>

    <p style="text-align: center; font-weight: bold; margin: 30px 0;">
      This is my commitment. This is my promise to myself.
    </p>

    ${commitment.futureSelfMessage ? `
    <div class="section" style="background: white; padding: 15px; border-radius: 4px; border: 1px solid #fbbf24;">
      <div class="section-title">P.S. - A Message to My Future Self:</div>
      <div class="section-content">${commitment.futureSelfMessage}</div>
    </div>
    ` : ''}

    <div class="signature">
      <div class="signature-line">${commitment.signatureName}</div>
      <div class="date">${formatDate(commitment.commitmentDate)}</div>
    </div>
  </div>
</body>
</html>
  `;

  // Create a blob and download
  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = '6-Month-Transformation-Commitment.html';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}


import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Check, Rocket } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Phase0() {
  const utils = trpc.useUtils();
  const { data: commitment } = trpc.commitment.get.useQuery();
  const { data: progressData } = trpc.progress.get.useQuery();
  
  const createCommitment = trpc.commitment.create.useMutation({
    onSuccess: () => {
      utils.commitment.get.invalidate();
      toast.success("Commitment letter saved! Your 'My Why' is now accessible anytime.");
    },
  });

  const markComplete = trpc.progress.markComplete.useMutation({
    onSuccess: () => {
      utils.progress.get.invalidate();
      toast.success("Phase 0 marked complete! 🎉");
    },
  });

  const [formData, setFormData] = useState({
    whyText: "",
    goal1: "",
    goal2: "",
    goal3: "",
    becomingText: "",
    setbackReminder: "",
    doingThisFor: "",
    signatureName: "",
    futureSelfMessage: "",
  });

  const isComplete = progressData?.progress?.some(
    p => p.phaseNumber === 0 && p.completed === 1
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.signatureName.trim()) {
      toast.error("Please sign your commitment letter");
      return;
    }

    const sixMonthsLater = new Date();
    sixMonthsLater.setMonth(sixMonthsLater.getMonth() + 6);

    createCommitment.mutate({
      whyText: formData.whyText,
      goal1: formData.goal1,
      goal2: formData.goal2,
      goal3: formData.goal3,
      becomingText: formData.becomingText,
      setbackReminder: formData.setbackReminder,
      doingThisFor: formData.doingThisFor,
      signatureName: formData.signatureName,
      futureSelfMessage: formData.futureSelfMessage || undefined,
    });
  };

  if (commitment) {
    return (
      <Card className="border border-gray-200 bg-white shadow-sm">
        <CardContent className="p-8">
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Commitment Letter Complete! 🎉</h2>
            <p className="text-gray-600 mb-6">
              Your "My Why" is now accessible anytime from the button in the header.
            </p>
            <p className="text-gray-700 font-medium">
              Ready to start Phase 1? Click <strong>"Define Your Vision"</strong> in the sidebar!
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const today = new Date().toLocaleDateString("en-US", { 
    year: "numeric", 
    month: "long", 
    day: "numeric" 
  });

  const sixMonthsLater = new Date();
  sixMonthsLater.setMonth(sixMonthsLater.getMonth() + 6);
  const futureDate = sixMonthsLater.toLocaleDateString("en-US", { 
    year: "numeric", 
    month: "long", 
    day: "numeric" 
  });

  return (
    <Card className="border border-gray-200 bg-white shadow-sm">
      <CardContent className="px-8 pt-6 pb-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Rocket className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Phase 0: Start Here</h1>
              <p className="text-sm text-gray-500 mt-1">Time to complete: 10 minutes</p>
            </div>
          </div>
          {isComplete && (
            <div className="flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-lg font-semibold">
              <Check className="h-5 w-5" />
              Complete
            </div>
          )}
        </div>

        {/* Welcome Section - NOT in a card */}
        <div className="border-l-4 border-l-blue-500 bg-blue-50 p-6 rounded-r-lg">
          <h2 className="text-3xl font-bold text-blue-900 mb-3">
            Welcome to Your 6-Month Transformation Journey!
          </h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            You're about to build a complete personal transformation system that will fundamentally change your life in the next 180 days.
          </p>
        </div>

        {/* What You're About to Build - In a card */}
        <Card className="border border-gray-200">
          <CardHeader>
            <CardTitle className="text-2xl">What You're About to Build</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">
              This isn't theory. This is a <strong>step-by-step implementation system</strong> that takes you from "I want to change" to "I've transformed my life" in 11 focused phases.
            </p>
            <p className="text-gray-700 font-semibold">By the end of this program, you'll have:</p>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">A crystal-clear transformation vision that excites and scares you</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">A personal philosophy and documentation system</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">An upgraded circle of influence</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">A 6-month self-education investment plan</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">Optimized environments that inspire you</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">Daily rituals that compound into massive results</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* The Key: Imperfect Action - In a card */}
        <Card className="border border-gray-200">
          <CardContent className="pt-6 space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">⚡ The Key: Imperfect Action</h3>
            <p className="text-gray-700">
              Don't wait for perfect. Don't overthink. <strong>Done is better than perfect.</strong> The people who transform their lives aren't the ones with perfect plans—they're the ones who TAKE ACTION.
            </p>
            <div className="border-l-4 border-l-yellow-400 bg-yellow-50 p-4 rounded-r-lg">
              <p className="text-sm font-semibold text-gray-900 mb-2">💡 Pro Tip:</p>
              <p className="text-sm text-gray-700">
                Set a timer for each phase. The time estimates are realistic. Don't let perfectionism slow you down. You can complete this entire program in 1-2 focused days!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Commitment Letter - In a card */}
        <Card className="border border-gray-200 bg-white">
          <CardHeader>
            <CardTitle className="text-2xl">Your Personal Commitment Letter</CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Take 10 minutes to complete this commitment letter to yourself. This will become your "My Why" - accessible anytime you need inspiration.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="bg-yellow-50 p-6 rounded-lg border border-yellow-200 space-y-4">
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-600">Today's Date: {today}</p>
                </div>
                
                <div className="text-left space-y-2">
                  <p className="text-base font-semibold text-gray-900">Dear Future Me,</p>
                  <p className="text-base text-gray-900">
                    Today, I am making a short 6-month commitment to myself, that will change the trajectory of my life FOREVER.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="why" className="text-base font-semibold text-gray-900">
                    I am committing to this transformation because:
                  </Label>
                  <Textarea
                    id="why"
                    value={formData.whyText}
                    onChange={(e) => setFormData({ ...formData, whyText: e.target.value })}
                    placeholder="What's driving this change? What's your deepest why?"
                    className="min-h-[100px] bg-white"
                    required
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-semibold text-gray-900">
                    Six months from now, on {futureDate}, I will have:
                  </Label>
                  <Input
                    value={formData.goal1}
                    onChange={(e) => setFormData({ ...formData, goal1: e.target.value })}
                    placeholder="Goal #1 (be specific)"
                    className="bg-white"
                    required
                  />
                  <Input
                    value={formData.goal2}
                    onChange={(e) => setFormData({ ...formData, goal2: e.target.value })}
                    placeholder="Goal #2 (be specific)"
                    className="bg-white"
                    required
                  />
                  <Input
                    value={formData.goal3}
                    onChange={(e) => setFormData({ ...formData, goal3: e.target.value })}
                    placeholder="Goal #3 (be specific)"
                    className="bg-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="becoming" className="text-base font-semibold text-gray-900">
                    The person I am becoming is someone who:
                  </Label>
                  <Textarea
                    id="becoming"
                    value={formData.becomingText}
                    onChange={(e) => setFormData({ ...formData, becomingText: e.target.value })}
                    placeholder="Character traits, habits, identity shift..."
                    className="min-h-[80px] bg-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="setbacks" className="text-base font-semibold text-gray-900">
                    I know this journey won't be easy. When I face setbacks, I will remember:
                  </Label>
                  <Textarea
                    id="setbacks"
                    value={formData.setbackReminder}
                    onChange={(e) => setFormData({ ...formData, setbackReminder: e.target.value })}
                    placeholder="What will keep you going when it's hard?"
                    className="min-h-[80px] bg-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doingFor" className="text-base font-semibold text-gray-900">
                    I am doing this for:
                  </Label>
                  <Textarea
                    id="doingFor"
                    value={formData.doingThisFor}
                    onChange={(e) => setFormData({ ...formData, doingThisFor: e.target.value })}
                    placeholder="Who/what does this transformation serve beyond yourself?"
                    className="min-h-[80px] bg-white"
                    required
                  />
                </div>

                <div className="pt-4 border-t border-gray-200 space-y-4">
                  <p className="text-sm text-gray-700">
                    <strong>P.S.</strong> - A Message to My Future Self: (Optional)
                  </p>
                  <p className="text-xs text-gray-500 italic">
                    A personal note to read when you complete the 6 months...
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signature" className="text-base font-semibold text-gray-900">
                    Your Signature (Type your full name):
                  </Label>
                  <Input
                    id="signature"
                    value={formData.signatureName}
                    onChange={(e) => setFormData({ ...formData, signatureName: e.target.value })}
                    placeholder="Your full name"
                    className="bg-white font-serif text-lg"
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg font-semibold"
                  disabled={createCommitment.isPending}
                >
                  {createCommitment.isPending ? "Saving..." : "Lock In My Commitment →"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Ready to Start */}
        <div className="text-center py-6 space-y-3">
          <p className="text-lg font-semibold text-gray-700">Ready to Start? 🚀</p>
          <p className="text-gray-600">
            Remember: <strong>Imperfect action beats perfect planning every single time.</strong>
          </p>
          <p className="text-gray-700 font-medium">You got this! 💪👊</p>
          
          {!isComplete && (
            <Button
              onClick={() => markComplete.mutate({ phaseNumber: 0 })}
              variant="outline"
              className="mt-4"
            >
              Mark Phase 0 Complete
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}


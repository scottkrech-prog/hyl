import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Check, Copy, LucideIcon } from "lucide-react";
import { toast } from "sonner";

interface PhasePageProps {
  phaseNumber: number;
  title: string;
  timeEstimate: string;
  whatYouCreate: string;
  goal: string;
  prompt: string;
  icon: LucideIcon;
}

export default function PhasePage({
  phaseNumber,
  title,
  timeEstimate,
  whatYouCreate,
  goal,
  prompt,
  icon: Icon,
}: PhasePageProps) {
  const utils = trpc.useUtils();
  const { data: progressData } = trpc.progress.get.useQuery();
  const markComplete = trpc.progress.markComplete.useMutation({
    onSuccess: () => {
      utils.progress.get.invalidate();
      toast.success(`Phase ${phaseNumber} marked complete! 🎉`);
    },
  });

  const isComplete = progressData?.progress?.some(
    p => p.phaseNumber === phaseNumber && p.completed === 1
  );

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(prompt);
    toast.success("Prompt copied! Paste it into ChatGPT, Claude, or Manus.");
  };

  const handleMarkComplete = () => {
    markComplete.mutate({ phaseNumber });
  };

  return (
    <Card className="border border-gray-200 bg-white shadow-sm">
      <CardContent className="px-8 pt-6 pb-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Phase {phaseNumber}: {title}
              </h1>
              <p className="text-sm text-gray-500 mt-1">Time to complete: {timeEstimate}</p>
            </div>
          </div>
          {isComplete && (
            <div className="flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-lg font-semibold">
              <Check className="h-5 w-5" />
              Complete
            </div>
          )}
        </div>

        {/* What You'll Create - NOT in a separate card */}
        <div className="border-l-4 border-l-blue-500 bg-blue-50 p-6 rounded-r-lg">
          <h2 className="text-2xl font-bold text-blue-900 mb-2">What You'll Create</h2>
          <p className="text-lg text-gray-700 leading-relaxed">{whatYouCreate}</p>
        </div>

        {/* The Goal - In a card */}
        <Card className="border border-gray-200">
          <CardHeader>
            <CardTitle className="text-2xl">The Goal</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed">{goal}</p>
          </CardContent>
        </Card>

        {/* AI Prompt - In a card */}
        <Card className="border border-gray-200 bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              🤖 Your AI Prompt
            </CardTitle>
            <CardDescription className="text-base">
              Copy this entire prompt and paste it into ChatGPT, Claude, or Manus. The AI will guide you through creating your deliverable for this phase.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-6 rounded-lg border border-blue-200 font-mono text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
              {prompt}
            </div>
            <Button 
              onClick={handleCopyPrompt} 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2"
              size="lg"
            >
              <Copy className="h-5 w-5" />
              Copy Prompt to Clipboard
            </Button>
            <div className="border-l-4 border-l-yellow-400 bg-yellow-50 p-4 rounded-r-lg">
              <p className="text-sm font-semibold text-gray-900 mb-2">💡 Pro Tip:</p>
              <p className="text-sm text-gray-700">
                After pasting the prompt, the AI will ask you questions one at a time. Answer thoughtfully but don't overthink—you can always refine later. The goal is progress, not perfection!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Mark Complete Section */}
        <div className="text-center py-6 space-y-4">
          <p className="text-lg font-semibold text-gray-700">Finished this phase? 🎉</p>
          <p className="text-gray-600">
            Mark it complete and move on to the next phase. Remember: <strong>momentum matters more than perfection!</strong>
          </p>
          {!isComplete && (
            <Button
              onClick={handleMarkComplete}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white"
              disabled={markComplete.isPending}
            >
              {markComplete.isPending ? "Saving..." : "Mark Complete"}
            </Button>
          )}
          {isComplete && (
            <p className="text-green-700 font-semibold">✅ Phase complete! Great work!</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}


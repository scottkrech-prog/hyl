// This file contains all phase components 2-11
// Each uses the PhasePage component with appropriate content

import PhasePage from "./PhasePage";
import { Users, DollarSign, Home, Trophy, Calendar, UserCheck, Focus, PartyPopper, Zap } from "lucide-react";

export function Phase2() {
  return (
    <PhasePage
      phaseNumber={2}
      title="Establish Your Success Philosophy"
      timeEstimate="30-45 minutes"
      whatYouCreate="A personal philosophy statement and documentation system for tracking your 6-month journey"
      goal="Define how you'll process events and challenges, establish your core principles for success, set up a journal/tracking system, and commit to becoming a 'serious student of your own life'"
      prompt="You are my AI Philosophy Coach helping me establish my personal success philosophy and documentation system based on Jim Rohn's principles. Guide me through creating a philosophy statement and setting up a tracking system for my 6-month transformation. Ask ONE question at a time. Help me articulate my core beliefs about success and guide me to set up practical documentation systems."
      icon={Users}
    />
  );
}

export function Phase3() {
  return (
    <PhasePage
      phaseNumber={3}
      title="Audit Your Circle of Influence"
      timeEstimate="45 minutes"
      whatYouCreate="A relationship audit and strategic plan for upgrading your circle of influence over the next 6 months"
      goal="Identify the 5 people you spend the most time with, assess whether they inspire or tire you, create a plan to increase exposure to inspiring people, and make strategic decisions about relationships"
      prompt="You are my AI Association Coach helping me audit and upgrade my circle of influence based on Jim Rohn's principle: 'You are the average of the five people you spend the most time with.' Guide me through a relationship audit and create a strategic plan for the next 6 months. Ask ONE question at a time. Be tactful but honest about relationships."
      icon={Users}
    />
  );
}

export function Phase4() {
  return (
    <PhasePage
      phaseNumber={4}
      title="Design Your Investment Strategy"
      timeEstimate="45-60 minutes"
      whatYouCreate="A comprehensive 6-month self-education and personal investment plan"
      goal="Commit to investing in yourself financially and time-wise, identify books/courses/seminars/coaching to pursue, create a learning roadmap aligned with your transformation goals"
      prompt="You are my AI Investment Coach helping me design a 6-month self-education and personal investment strategy based on Jim Rohn's principle: 'Formal education will make you a living, self-education will make you a fortune.' Guide me through creating a comprehensive learning and investment plan. Ask ONE question at a time. Challenge me to invest in myself."
      icon={DollarSign}
    />
  );
}

export function Phase5() {
  return (
    <PhasePage
      phaseNumber={5}
      title="Optimize Your Environment"
      timeEstimate="30-45 minutes"
      whatYouCreate="An environment transformation plan for your physical and digital spaces"
      goal="Design environments that inspire rather than expire you, create spaces that support your goals, eliminate environmental obstacles, and set up visual reminders and triggers"
      prompt="You are my AI Environment Coach helping me optimize my physical and digital environments based on Jim Rohn's principle: 'Your environment will either inspire you or expire you.' Guide me through auditing and transforming my environment to support my 6-month transformation. Ask ONE question at a time."
      icon={Home}
    />
  );
}

export function Phase6() {
  return (
    <PhasePage
      phaseNumber={6}
      title="Set Your Breakthrough Goals"
      timeEstimate="45-60 minutes"
      whatYouCreate="A comprehensive goal architecture with stretch goals and raised standards across all life areas"
      goal="Set goals that 'scare you a little bit', break big goals into daily activities, raise standards in relationships/health/income/business, and create measurement systems for each goal"
      prompt="You are my AI Goal Setting Coach helping me set breakthrough goals and raise my standards based on Jim Rohn's principles. Guide me through creating goals that scare me a little, breaking them into daily actions, and raising my standards across all life areas. Ask ONE question at a time. Push me to set bigger goals."
      icon={Trophy}
    />
  );
}

export function Phase7() {
  return (
    <PhasePage
      phaseNumber={7}
      title="Build Your Daily Success Rituals"
      timeEstimate="60 minutes"
      whatYouCreate="A complete daily ritual system (morning and evening) designed to compound into massive results"
      goal="Design morning ritual that sets you up for success, create evening ritual that ensures reflection and preparation, build in 1% daily improvement tracking, and establish non-negotiable daily habits"
      prompt="You are my AI Ritual Design Coach helping me build daily success rituals based on Jim Rohn's principles of daily rituals and incrementalism. Guide me through designing morning and evening rituals that will compound into massive transformation over 6 months. Ask ONE question at a time. Emphasize the compound effect of small daily actions."
      icon={Calendar}
    />
  );
}

export function Phase8() {
  return (
    <PhasePage
      phaseNumber={8}
      title="Create Your Accountability System"
      timeEstimate="30-45 minutes"
      whatYouCreate="A comprehensive accountability system including partners, check-ins, and commitment mechanisms"
      goal="Find accountability partner(s) or join mastermind group, set up regular check-in schedule, create commitment mechanisms, and establish progress reporting system"
      prompt="You are my AI Accountability Coach helping me create a comprehensive accountability system based on Jim Rohn's principle of accountability. Guide me through finding accountability partners and setting up systems that will keep me on track for 6 months. Ask ONE question at a time."
      icon={UserCheck}
    />
  );
}

export function Phase9() {
  return (
    <PhasePage
      phaseNumber={9}
      title="Master Focus & Recovery"
      timeEstimate="45 minutes"
      whatYouCreate="A focus management system and setback recovery playbook"
      goal="Develop laser focus on priorities, eliminate distractions and time-wasters, create protocols for handling setbacks, and build resilience and bounce-back capacity"
      prompt="You are my AI Focus & Resilience Coach helping me master focus and recovery based on Jim Rohn's principles. Guide me through creating a focus management system and setback recovery playbook. Ask ONE question at a time. Help me identify and eliminate distractions."
      icon={Focus}
    />
  );
}

export function Phase10() {
  return (
    <PhasePage
      phaseNumber={10}
      title="Build Celebration & Gratitude Practices"
      timeEstimate="30 minutes"
      whatYouCreate="Systems for celebrating progress and maintaining daily gratitude practice"
      goal="Create celebration milestones throughout 6-month journey, establish daily gratitude practice, build momentum through recognition of progress, and maintain positive mindset and appreciation"
      prompt="You are my AI Celebration & Gratitude Coach helping me build celebration and gratitude practices based on Jim Rohn's principles. Guide me through creating systems for celebrating progress and maintaining daily gratitude. Ask ONE question at a time. Emphasize celebrating progress, not just achievements."
      icon={PartyPopper}
    />
  );
}

export function Phase11() {
  return (
    <PhasePage
      phaseNumber={11}
      title="Deploy Your 6-Month Transformation Plan"
      timeEstimate="30-45 minutes"
      whatYouCreate="Your complete, integrated 6-Month Transformation Blueprint ready for immediate implementation"
      goal="Integrate all phases into one cohesive plan, create Day 1 action checklist, set up 6-month calendar with milestones, make final commitment to the journey, and identify first week priorities"
      prompt="You are my AI Integration Coach helping me deploy my complete 6-Month Transformation Plan. Guide me through integrating all 10 previous phases into one cohesive blueprint and preparing for Day 1 implementation. Ask ONE question at a time. Help me see how all phases work together. Create concrete Day 1 and Week 1 action plans. Inspire final commitment."
      icon={Zap}
    />
  );
}


import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Check, Download, Heart, LogOut, Menu, Rocket, Target, Users, DollarSign, Home, Trophy, Calendar, UserCheck, Focus, PartyPopper, Zap, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { APP_TITLE } from "@/const";
import { generateTransformationPDF } from "@/lib/pdfExport";
import { toast } from "sonner";

const PHASES = [
  { number: 0, title: "Start Here", path: "/phase/0", time: "10 min", icon: Rocket, color: "blue" },
  { number: 1, title: "Define Your Vision", path: "/phase/1", time: "30-45 min", icon: Target, color: "yellow" },
  { number: 2, title: "Success Philosophy", path: "/phase/2", time: "30-45 min", icon: Users, color: "purple" },
  { number: 3, title: "Circle of Influence", path: "/phase/3", time: "45 min", icon: Users, color: "teal" },
  { number: 4, title: "Investment Strategy", path: "/phase/4", time: "45-60 min", icon: DollarSign, color: "pink" },
  { number: 5, title: "Optimize Environment", path: "/phase/5", time: "30-45 min", icon: Home, color: "purple" },
  { number: 6, title: "Breakthrough Goals", path: "/phase/6", time: "45-60 min", icon: Trophy, color: "orange" },
  { number: 7, title: "Daily Rituals", path: "/phase/7", time: "60 min", icon: Calendar, color: "green" },
  { number: 8, title: "Accountability System", path: "/phase/8", time: "30-45 min", icon: UserCheck, color: "red" },
  { number: 9, title: "Focus & Recovery", path: "/phase/9", time: "45 min", icon: Focus, color: "blue" },
  { number: 10, title: "Celebration & Gratitude", path: "/phase/10", time: "30 min", icon: PartyPopper, color: "yellow" },
  { number: 11, title: "Deploy Your Plan", path: "/phase/11", time: "30-45 min", icon: Zap, color: "red" },
];

const colorMap: Record<string, { border: string; bg: string; badge: string }> = {
  blue: { border: "border-l-blue-500", bg: "bg-blue-50", badge: "bg-blue-500" },
  yellow: { border: "border-l-yellow-500", bg: "bg-yellow-50", badge: "bg-yellow-500" },
  purple: { border: "border-l-purple-500", bg: "bg-purple-50", badge: "bg-purple-500" },
  teal: { border: "border-l-teal-500", bg: "bg-teal-50", badge: "bg-teal-500" },
  pink: { border: "border-l-pink-500", bg: "bg-pink-50", badge: "bg-pink-500" },
  orange: { border: "border-l-orange-500", bg: "bg-orange-50", badge: "bg-orange-500" },
  green: { border: "border-l-green-500", bg: "bg-green-50", badge: "bg-green-500" },
  red: { border: "border-l-red-500", bg: "bg-red-50", badge: "bg-red-500" },
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showMyWhy, setShowMyWhy] = useState(false);

  const { data: progressData } = trpc.progress.get.useQuery();
  const { data: commitment } = trpc.commitment.get.useQuery();

  const completedPhases = progressData?.progress?.filter(p => p.completed === 1).map(p => p.phaseNumber) || [];
  const completedCount = progressData?.count || 0;

  const formatDate = (date: Date | null | undefined) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Rocket className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">{APP_TITLE}</h1>
                <p className="text-xs text-gray-500 hidden sm:block">Complete Step-by-Step Transformation System</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-right mr-2 hidden sm:block">
              <div className="text-xs text-gray-500">Progress</div>
              <div className="text-lg font-bold text-blue-600">{Math.round((completedCount / 12) * 100)}%</div>
              <div className="text-xs text-gray-400">{completedCount} of 12 phases</div>
            </div>
            
            {commitment && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    generateTransformationPDF(commitment);
                    toast.success("Commitment letter downloaded!");
                  }}
                  className="gap-2"
                >
                  <Download className="h-4 w-4" />
                  <span className="hidden sm:inline">Download</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowMyWhy(true)}
                  className="gap-2 border-yellow-400 text-yellow-700 hover:bg-yellow-50"
                >
                  <Heart className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="hidden sm:inline">My Why</span>
                </Button>
              </>
            )}
            

          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`
            fixed lg:sticky top-[73px] left-0 z-30 h-[calc(100vh-73px)]
            w-64 bg-white border-r border-gray-200 overflow-y-auto
            transition-transform duration-300 ease-in-out
            ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
          `}
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          <div className="p-3 space-y-2">
            {/* Phase Navigation */}
            {PHASES.map((phase) => {
              const isActive = location === phase.path;
              const isComplete = completedPhases.includes(phase.number);
              const colors = colorMap[phase.color];
              const Icon = phase.icon;

              return (
                <Link key={phase.number} href={phase.path}>
                  <div
                    className={`
                      block border-l-4 ${colors.border} ${isActive ? colors.bg : 'bg-white'}
                      rounded-r-lg p-3 transition-all duration-150 hover:shadow-md
                      ${isActive ? 'shadow-md' : 'hover:bg-gray-50'}
                      ${!isActive ? 'opacity-50' : 'opacity-100'}
                    `}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`
                          flex items-center justify-center w-8 h-8 rounded-full text-white shrink-0
                          ${isComplete ? 'bg-green-500' : colors.badge}
                        `}
                      >
                        {isComplete ? <Check className="h-5 w-5" /> : <Icon className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className={`font-semibold text-sm leading-tight ${
                          isActive ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {phase.title}
                        </div>
                        <div className={`text-xs mt-1 ${
                          isActive ? 'text-gray-500' : 'text-gray-400'
                        }`}>{phase.time}</div>
                      </div>
                      {isComplete && (
                        <div className="text-xs font-medium text-green-600 bg-green-100 px-2 py-0.5 rounded">
                          ✓
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8">
          <div className="max-w-4xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* My Why Dialog */}
      <Dialog open={showMyWhy} onOpenChange={setShowMyWhy}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center mb-4">
              My 6-Month Transformation Commitment
            </DialogTitle>
          </DialogHeader>
          
          {commitment && (
            <div className="space-y-6 p-6 bg-gradient-to-br from-amber-50 to-yellow-50 rounded-lg border-2 border-yellow-200">
              <div className="text-center">
                <div className="text-sm text-gray-600">Commitment Date</div>
                <div className="font-semibold">{formatDate(commitment.commitmentDate)}</div>
              </div>

              <div className="prose prose-sm max-w-none">
                <p className="text-lg font-semibold text-center mb-4">Dear Future Me,</p>
                
                <p className="text-base font-medium">
                  Today, I am making a short 6-month commitment to myself, that will change the trajectory of my life FOREVER.
                </p>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">I am committing to this transformation because:</p>
                  <p className="italic">{commitment.whyText}</p>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">Six months from now, on {formatDate(commitment.targetDate)}, I will have:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>{commitment.goal1}</li>
                    <li>{commitment.goal2}</li>
                    <li>{commitment.goal3}</li>
                  </ul>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">The person I am becoming is someone who:</p>
                  <p className="italic">{commitment.becomingText}</p>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">I know this journey won't be easy. When I face setbacks, I will remember:</p>
                  <p className="italic">{commitment.setbackReminder}</p>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">I am doing this for:</p>
                  <p className="italic">{commitment.doingThisFor}</p>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">I commit to:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Completing all 11 phases of this planning system</li>
                    <li>Starting Day 1 immediately after completion</li>
                    <li>Following my daily rituals consistently</li>
                    <li>Getting up one more time than I fall down</li>
                    <li>Becoming the person I'm meant to be</li>
                  </ul>
                </div>

                <div className="my-4">
                  <p className="font-semibold text-gray-700">I understand that:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Imperfect action beats perfect planning</li>
                    <li>What's easy to do is also easy not to do - I choose to do</li>
                    <li>For things to change, I must change</li>
                    <li>Six months from now, I will look back at this moment as the turning point</li>
                  </ul>
                </div>

                <p className="font-semibold text-center my-4">
                  This is my commitment. This is my promise to myself.
                </p>

                <div className="text-center my-4">
                  <p className="font-semibold">Signed: {commitment.signatureName}</p>
                  <p className="text-sm text-gray-600">Date: {formatDate(commitment.commitmentDate)}</p>
                </div>

                {commitment.futureSelfMessage && (
                  <div className="mt-6 p-4 bg-white rounded-lg border border-yellow-300">
                    <p className="font-semibold text-gray-700">P.S. - A Message to My Future Self:</p>
                    <p className="italic mt-2">{commitment.futureSelfMessage}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}


import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import PasswordGate from "./components/PasswordGate";
import { useState, useEffect } from "react";
import DashboardLayout from "./components/DashboardLayout";
import Phase0 from "./pages/Phase0";
import Phase1 from "./pages/Phase1";
import { Phase2, Phase3, Phase4, Phase5, Phase6, Phase7, Phase8, Phase9, Phase10, Phase11 } from "./pages/AllPhases";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Phase0} />
        <Route path="/phase/0" component={Phase0} />
        <Route path="/phase/1" component={Phase1} />
        <Route path="/phase/2" component={Phase2} />
        <Route path="/phase/3" component={Phase3} />
        <Route path="/phase/4" component={Phase4} />
        <Route path="/phase/5" component={Phase5} />
        <Route path="/phase/6" component={Phase6} />
        <Route path="/phase/7" component={Phase7} />
        <Route path="/phase/8" component={Phase8} />
        <Route path="/phase/9" component={Phase9} />
        <Route path="/phase/10" component={Phase10} />
        <Route path="/phase/11" component={Phase11} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const auth = sessionStorage.getItem("app_authenticated");
    if (auth === "true") {
      setIsAuthenticated(true);
    }
  }, []);

  if (!isAuthenticated) {
    return (
      <ErrorBoundary>
        <ThemeProvider defaultTheme="light">
          <TooltipProvider>
            <Toaster />
            <PasswordGate onSuccess={() => setIsAuthenticated(true)} />
          </TooltipProvider>
        </ThemeProvider>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

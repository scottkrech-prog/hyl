import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Commitment letters created by users in Phase 0
 */
export const commitmentLetters = mysqlTable("commitment_letters", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  whyText: text("whyText").notNull(),
  goal1: text("goal1").notNull(),
  goal2: text("goal2").notNull(),
  goal3: text("goal3").notNull(),
  becomingText: text("becomingText").notNull(),
  setbackReminder: text("setbackReminder").notNull(),
  doingThisFor: text("doingThisFor").notNull(),
  futureSelfMessage: text("futureSelfMessage"),
  signatureName: varchar("signatureName", { length: 255 }).notNull(),
  commitmentDate: timestamp("commitmentDate").notNull(),
  targetDate: timestamp("targetDate").notNull(),
  locked: int("locked").default(0).notNull(), // 0 = unlocked, 1 = locked
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommitmentLetter = typeof commitmentLetters.$inferSelect;
export type InsertCommitmentLetter = typeof commitmentLetters.$inferInsert;

/**
 * User progress tracking for the 11 phases
 */
export const userProgress = mysqlTable("user_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseNumber: int("phaseNumber").notNull(), // 0-11
  completed: int("completed").default(0).notNull(), // 0 = not complete, 1 = complete
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = typeof userProgress.$inferInsert;
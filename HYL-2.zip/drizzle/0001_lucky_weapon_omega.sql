CREATE TABLE `commitment_letters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`whyText` text NOT NULL,
	`goal1` text NOT NULL,
	`goal2` text NOT NULL,
	`goal3` text NOT NULL,
	`becomingText` text NOT NULL,
	`setbackReminder` text NOT NULL,
	`doingThisFor` text NOT NULL,
	`futureSelfMessage` text,
	`signatureName` varchar(255) NOT NULL,
	`commitmentDate` timestamp NOT NULL,
	`targetDate` timestamp NOT NULL,
	`locked` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `commitment_letters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phaseNumber` int NOT NULL,
	`completed` int NOT NULL DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_progress_id` PRIMARY KEY(`id`)
);

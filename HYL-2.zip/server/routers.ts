import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  commitment: router({
    get: publicProcedure.query(async () => {
      // Use guest user ID = 1
      return await db.getCommitmentLetterByUserId(1);
    }),
    
    create: publicProcedure
      .input(z.object({
        whyText: z.string(),
        goal1: z.string(),
        goal2: z.string(),
        goal3: z.string(),
        becomingText: z.string(),
        setbackReminder: z.string(),
        doingThisFor: z.string(),
        futureSelfMessage: z.string().optional(),
        signatureName: z.string(),
      }))
      .mutation(async ({ input }) => {
        const commitmentDate = new Date();
        const targetDate = new Date();
        targetDate.setMonth(targetDate.getMonth() + 6);
        
        await db.createCommitmentLetter({
          userId: 1, // Guest user
          ...input,
          commitmentDate,
          targetDate,
          locked: 0,
        });
        
        return { success: true };
      }),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        whyText: z.string().optional(),
        goal1: z.string().optional(),
        goal2: z.string().optional(),
        goal3: z.string().optional(),
        becomingText: z.string().optional(),
        setbackReminder: z.string().optional(),
        doingThisFor: z.string().optional(),
        futureSelfMessage: z.string().optional(),
        signatureName: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        await db.updateCommitmentLetter(id, updates);
        return { success: true };
      }),
  }),
  
  progress: router({
    get: publicProcedure.query(async () => {
      // Use guest user ID = 1
      const progress = await db.getUserProgress(1);
      const count = await db.getProgressCount(1);
      return { progress, count };
    }),
    
    markComplete: publicProcedure
      .input(z.object({
        phaseNumber: z.number().min(0).max(11),
      }))
      .mutation(async ({ input }) => {
        // Use guest user ID = 1
        await db.markPhaseComplete(1, input.phaseNumber);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
